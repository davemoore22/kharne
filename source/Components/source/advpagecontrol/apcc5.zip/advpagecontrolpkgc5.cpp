//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("AdvPageControlPkgC5.res");
USEPACKAGE("vcl50.bpi");
USEUNIT("AdvPageControlreg.pas");
USERES("AdvPageControlreg.dcr");
USEPACKAGE("dsnide50.bpi");
USEUNIT("AdvTabSetReg.pas");
USERES("AdvTabSetReg.dcr");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
