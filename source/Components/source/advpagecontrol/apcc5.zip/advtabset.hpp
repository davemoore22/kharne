// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'AdvTabSet.pas' rev: 5.00

#ifndef AdvTabSetHPP
#define AdvTabSetHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Menus.hpp>	// Pascal unit
#include <ImgList.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Advtabset
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TScrollBtn { sbLeft, sbRight };
#pragma option pop

class DELPHICLASS TScroller;
class PASCALIMPLEMENTATION TScroller : public Controls::TCustomControl 
{
	typedef Controls::TCustomControl inherited;
	
private:
	int FMin;
	int FMax;
	int FPosition;
	Classes::TNotifyEvent FOnClick;
	int FChange;
	Graphics::TColor FArrowColor;
	Graphics::TBitmap* Bitmap;
	bool Pressed;
	bool Down;
	TScrollBtn Current;
	int pWidth;
	int pHeight;
	void __fastcall SetMin(int Value);
	void __fastcall SetMax(int Value);
	void __fastcall SetPosition(int Value);
	void __fastcall SetArrowColor(Graphics::TColor Value);
	bool __fastcall CanScrollLeft(void);
	bool __fastcall CanScrollRight(void);
	HIDESBASE void __fastcall DoMouseDown(int X);
	HIDESBASE MESSAGE void __fastcall WMLButtonDown(Messages::TWMMouse &Message);
	HIDESBASE MESSAGE void __fastcall WMLButtonDblClk(Messages::TWMMouse &Message);
	HIDESBASE MESSAGE void __fastcall WMMouseMove(Messages::TWMMouse &Message);
	HIDESBASE MESSAGE void __fastcall WMLButtonUp(Messages::TWMMouse &Message);
	HIDESBASE MESSAGE void __fastcall WMSize(Messages::TWMSize &Message);
	void __fastcall DrawSBLeftDIS(Graphics::TCanvas* aCanvas);
	void __fastcall DrawSBLeftDN(Graphics::TCanvas* aCanvas);
	void __fastcall DrawSBLeft(Graphics::TCanvas* aCanvas);
	void __fastcall DrawSBRightDIS(Graphics::TCanvas* aCanvas);
	void __fastcall DrawSBRight(Graphics::TCanvas* aCanvas);
	void __fastcall DrawSBRightDN(Graphics::TCanvas* aCanvas);
	
public:
	__fastcall virtual TScroller(Classes::TComponent* AOwner);
	__fastcall virtual ~TScroller(void);
	virtual void __fastcall Paint(void);
	
__published:
	__property Classes::TNotifyEvent OnClick = {read=FOnClick, write=FOnClick};
	__property int Min = {read=FMin, write=SetMin, default=0};
	__property int Max = {read=FMax, write=SetMax, default=0};
	__property int Position = {read=FPosition, write=SetPosition, default=0};
	__property int Change = {read=FChange, write=FChange, default=1};
	__property Graphics::TColor ArrowColor = {read=FArrowColor, write=SetArrowColor, default=-2147483627
		};
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TScroller(HWND ParentWindow) : Controls::TCustomControl(
		ParentWindow) { }
	#pragma option pop
	
};


class DELPHICLASS TTabList;
class DELPHICLASS TAdvTabSet;
#pragma option push -b-
enum TTabStyle { tsStandard, tsOwnerDraw };
#pragma option pop

typedef void __fastcall (__closure *TMeasureTabEvent)(System::TObject* Sender, int Index, int &TabWidth
	);

typedef void __fastcall (__closure *TDrawTabEvent)(System::TObject* Sender, Graphics::TCanvas* TabCanvas
	, const Windows::TRect &R, int Index, bool Selected);

typedef void __fastcall (__closure *TTabChangeEvent)(System::TObject* Sender, int NewTab, bool &AllowChange
	);

class DELPHICLASS TTabCollection;
class DELPHICLASS TTabCollectionItem;
class PASCALIMPLEMENTATION TTabCollection : public Classes::TCollection 
{
	typedef Classes::TCollection inherited;
	
private:
	TAdvTabSet* FOwner;
	HIDESBASE TTabCollectionItem* __fastcall GetItem(int Index);
	HIDESBASE void __fastcall SetItem(int Index, const TTabCollectionItem* Value);
	
public:
	__fastcall TTabCollection(TAdvTabSet* AOwner);
	__property TTabCollectionItem* Items[int Index] = {read=GetItem, write=SetItem/*, default*/};
	__property TAdvTabSet* AdvTabSet = {read=FOwner};
	HIDESBASE TTabCollectionItem* __fastcall Add(void);
	HIDESBASE TTabCollectionItem* __fastcall Insert(int Index);
	DYNAMIC Classes::TPersistent* __fastcall GetOwner(void);
public:
	#pragma option push -w-inl
	/* TCollection.Destroy */ inline __fastcall virtual ~TTabCollection(void) { }
	#pragma option pop
	
};


#pragma option push -b-
enum TGradientDirection { gdVertical, gdHorizontal };
#pragma option pop

class DELPHICLASS TTabMargin;
typedef int TMarginSize;

typedef void __fastcall (__closure *TMarginChange)(TMarginSize NewValue, TMarginSize OldValue, int Index
	);

class PASCALIMPLEMENTATION TTabMargin : public Classes::TPersistent 
{
	typedef Classes::TPersistent inherited;
	
private:
	TMarginSize FLeftMargin;
	TMarginSize FTopMargin;
	TMarginChange FOnMarginChange;
	void __fastcall SetMargin(int Index, TMarginSize Value);
	
protected:
	__property TMarginChange OnMarginChange = {read=FOnMarginChange, write=FOnMarginChange};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	
__published:
	__property TMarginSize LeftMargin = {read=FLeftMargin, write=SetMargin, index=0, default=0};
	__property TMarginSize TopMargin = {read=FTopMargin, write=SetMargin, index=1, default=0};
public:
	#pragma option push -w-inl
	/* TPersistent.Destroy */ inline __fastcall virtual ~TTabMargin(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TTabMargin(void) : Classes::TPersistent() { }
	#pragma option pop
	
};


typedef Shortint TTabOverlapSize;

typedef void __fastcall (__closure *TTabCloseEvent)(System::TObject* Sender, int TabIndex);

#pragma option push -b-
enum TAdvTabStyle { tsClassic, tsDotNet };
#pragma option pop

class PASCALIMPLEMENTATION TAdvTabSet : public Controls::TCustomControl 
{
	typedef Controls::TCustomControl inherited;
	
private:
	int FStartMargin;
	int FEndMargin;
	Classes::TStrings* FTabs;
	int FTabIndex;
	int FFirstIndex;
	int FVisibleTabs;
	Graphics::TColor FSelectedColor;
	Graphics::TColor FUnselectedColor;
	Graphics::TColor FBackgroundColor;
	bool FDitherBackground;
	bool FAutoScroll;
	TTabStyle FStyle;
	int FOwnerDrawHeight;
	TMeasureTabEvent FOnMeasureTab;
	TDrawTabEvent FOnDrawTab;
	TTabChangeEvent FOnChange;
	TTabCollection* FAdvTabs;
	Graphics::TColor FSelectedColorTo;
	Graphics::TColor FUnSelectedColorTo;
	Graphics::TColor FTextColor;
	Graphics::TColor FTabBorderColor;
	Graphics::TBitmap* FTabBackGround;
	Graphics::TBitmap* FTabBackGroundSelected;
	TGradientDirection FGradientDirection;
	TGradientDirection FHoverGradientDirection;
	Graphics::TColor FTabHoverColor;
	Graphics::TColor FTabHoverColorTo;
	Graphics::TColor FTabHoverBorder;
	Imglist::TCustomImageList* FImages;
	TTabMargin* FTabMargin;
	TTabOverlapSize FTabOverlap;
	bool FShowFocus;
	TTabCloseEvent FOnTabClose;
	TAdvTabStyle FAdvTabStyle;
	bool FHoverClosedButton;
	Classes::TStringList* FDuplicateTabs;
	int FHoverTab;
	Controls::TImageList* ImageList;
	Graphics::TBitmap* MemBitmap;
	Graphics::TBitmap* BrushBitmap;
	Classes::TList* TabPositions;
	int FTabHeight;
	TScroller* FScroller;
	bool FDoFix;
	bool FSoftTop;
	void __fastcall SetSelectedColor(Graphics::TColor Value);
	void __fastcall SetUnselectedColor(Graphics::TColor Value);
	void __fastcall SetBackgroundColor(Graphics::TColor Value);
	void __fastcall SetDitherBackground(bool Value);
	void __fastcall SetAutoScroll(bool Value);
	void __fastcall SetStartMargin(int Value);
	void __fastcall SetEndMargin(int Value);
	void __fastcall SetTabIndex(int Value);
	void __fastcall SetFirstIndex(int Value);
	void __fastcall SetTabList(Classes::TStrings* Value);
	void __fastcall SetTabStyle(TTabStyle Value);
	void __fastcall SetTabHeight(int Value);
	void __fastcall SetSelectedColorTo(Graphics::TColor Value);
	void __fastcall SetUnSelectedColorTo(Graphics::TColor Value);
	void __fastcall SetTextColor(Graphics::TColor Value);
	void __fastcall SetTabBorderColor(Graphics::TColor Value);
	void __fastcall SetTabBackGround(const Graphics::TBitmap* Value);
	void __fastcall SetTabBackGroundSelected(const Graphics::TBitmap* Value);
	void __fastcall SetGradientDirection(TGradientDirection Value);
	void __fastcall SetHoverGradientDirection(TGradientDirection value);
	void __fastcall SetTabMargin(TTabMargin* Value);
	void __fastcall SetTabOverlap(TTabOverlapSize Value);
	void __fastcall SetImages(Imglist::TCustomImageList* value);
	void __fastcall SetAdvTabStyle(TAdvTabStyle Value);
	HIDESBASE MESSAGE void __fastcall WMSize(Messages::TWMSize &Message);
	HIDESBASE MESSAGE void __fastcall CMSysColorChange(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMFontChanged(Messages::TMessage &Message);
	void __fastcall CreateBrushPattern(Graphics::TBitmap* Bitmap);
	int __fastcall CalcTabPositions(int Start, int Stop, Graphics::TCanvas* Canvas, int First);
	void __fastcall CreateScroller(void);
	void __fastcall InitBitmaps(void);
	void __fastcall DoneBitmaps(void);
	void __fastcall CreateEdgeParts(void);
	void __fastcall FixTabPos(void);
	MESSAGE void __fastcall WMGetDlgCode(Messages::TWMNoParams &Message);
	HIDESBASE MESSAGE void __fastcall CMDialogChar(Messages::TWMKey &Message);
	void __fastcall ScrollClick(System::TObject* Sender);
	void __fastcall ReadIntData(Classes::TReader* Reader);
	void __fastcall ReadBoolData(Classes::TReader* Reader);
	void __fastcall SetSoftTop(const bool Value);
	void __fastcall DrawCloseButton(Graphics::TCanvas* Canvas, const Windows::TRect &Rect, bool Active)
		;
	void __fastcall DrawHoverCloseButton(const Windows::TRect &Rect);
	void __fastcall DrawDownCloseButton(const Windows::TRect &Rect);
	bool __fastcall IsOnButton(int TabIndex, int X, int Y)/* overload */;
	bool __fastcall IsOnButton(int TabIndex, int X, int Y, Windows::TRect &aRect)/* overload */;
	void __fastcall TabMarginChange(TMarginSize NewValue, TMarginSize OldValue, int Index);
	void __fastcall SetOriginalTabWidth(void);
	void __fastcall IncTabWidth(int w);
	
protected:
	virtual void __fastcall CreateParams(Controls::TCreateParams &Params);
	DYNAMIC void __fastcall MouseMove(Classes::TShiftState Shift, int X, int Y);
	DYNAMIC void __fastcall MouseDown(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, 
		int Y);
	DYNAMIC void __fastcall MouseUp(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int 
		Y);
	HIDESBASE MESSAGE void __fastcall CMMouseLeave(Messages::TMessage &Message);
	virtual void __fastcall Paint(void);
	virtual void __fastcall DrawTab(Graphics::TCanvas* TabCanvas, const Windows::TRect &R, int Index, bool 
		Selected);
	bool __fastcall CanChange(int NewIndex);
	DYNAMIC void __fastcall GetChildren(Classes::TGetChildProc Proc, Classes::TComponent* Root);
	virtual void __fastcall MeasureTab(int Index, int &TabWidth);
	virtual void __fastcall DefineProperties(Classes::TFiler* Filer);
	void __fastcall AdjustTabWidth(void);
	__property Classes::TStringList* DuplicateTabs = {read=FDuplicateTabs};
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation AOperation
		);
	virtual void __fastcall Loaded(void);
	__property TScroller* Scroller = {read=FScroller};
	__property Classes::TStrings* Tabs = {read=FTabs, write=SetTabList};
	__property TTabStyle Style = {read=FStyle, write=SetTabStyle, default=1};
	__property bool DitherBackground = {read=FDitherBackground, write=SetDitherBackground, default=0};
	
public:
	__fastcall virtual TAdvTabSet(Classes::TComponent* AOwner);
	__fastcall virtual ~TAdvTabSet(void);
	int __fastcall ItemAtPos(const Windows::TPoint &Pos);
	Windows::TRect __fastcall ItemRect(int Item);
	int __fastcall ItemWidth(int Index);
	Windows::TRect __fastcall MinClientRect()/* overload */;
	Windows::TRect __fastcall MinClientRect(bool IncludeScroller)/* overload */;
	Windows::TRect __fastcall MinClientRect(int TabCount, bool IncludeScroller)/* overload */;
	HIDESBASE void __fastcall SelectNext(bool Direction);
	__property Canvas ;
	__property int FirstIndex = {read=FFirstIndex, write=SetFirstIndex, default=0};
	
__published:
	__property Align ;
	__property Anchors ;
	__property bool AutoScroll = {read=FAutoScroll, write=SetAutoScroll, default=1};
	__property Graphics::TColor BackgroundColor = {read=FBackgroundColor, write=SetBackgroundColor, default=-2147483633
		};
	__property Constraints ;
	__property DragCursor ;
	__property DragKind ;
	__property DragMode ;
	__property Enabled ;
	__property int EndMargin = {read=FEndMargin, write=SetEndMargin, default=5};
	__property Font ;
	__property ParentShowHint ;
	__property PopupMenu ;
	__property ShowHint ;
	__property int StartMargin = {read=FStartMargin, write=SetStartMargin, default=5};
	__property Graphics::TColor SelectedColor = {read=FSelectedColor, write=SetSelectedColor, default=-2147483633
		};
	__property bool SoftTop = {read=FSoftTop, write=SetSoftTop, default=0};
	__property TTabCollection* AdvTabs = {read=FAdvTabs, write=FAdvTabs};
	__property Graphics::TColor SelectedColorTo = {read=FSelectedColorTo, write=SetSelectedColorTo, default=536870911
		};
	__property Graphics::TColor UnSelectedColorTo = {read=FUnSelectedColorTo, write=SetUnSelectedColorTo
		, default=536870911};
	__property Graphics::TColor TextColor = {read=FTextColor, write=SetTextColor, default=0};
	__property Graphics::TColor TabBorderColor = {read=FTabBorderColor, write=SetTabBorderColor, default=8421504
		};
	__property Graphics::TBitmap* TabBackGround = {read=FTabBackGround, write=SetTabBackGround};
	__property Graphics::TBitmap* TabBackGroundSelected = {read=FTabBackGroundSelected, write=SetTabBackGroundSelected
		};
	__property TGradientDirection GradientDirection = {read=FGradientDirection, write=SetGradientDirection
		, nodefault};
	__property TGradientDirection HoverGradientDirection = {read=FHoverGradientDirection, write=SetHoverGradientDirection
		, default=0};
	__property Graphics::TColor TabHoverColor = {read=FTabHoverColor, write=FTabHoverColor, default=536870911
		};
	__property Graphics::TColor TabHoverColorTo = {read=FTabHoverColorTo, write=FTabHoverColorTo, default=536870911
		};
	__property Graphics::TColor TabHoverBorder = {read=FTabHoverBorder, write=FTabHoverBorder, default=536870911
		};
	__property TTabMargin* TabMargin = {read=FTabMargin, write=SetTabMargin};
	__property TTabOverlapSize TabOverlap = {read=FTabOverlap, write=SetTabOverlap, nodefault};
	__property bool ShowFocus = {read=FShowFocus, write=FShowFocus, default=0};
	__property Imglist::TCustomImageList* Images = {read=FImages, write=SetImages};
	__property TAdvTabStyle TabStyle = {read=FAdvTabStyle, write=SetAdvTabStyle, default=0};
	__property TTabCloseEvent OnTabClose = {read=FOnTabClose, write=FOnTabClose};
	__property int TabHeight = {read=FOwnerDrawHeight, write=SetTabHeight, default=20};
	__property int TabIndex = {read=FTabIndex, write=SetTabIndex, default=-1};
	__property Graphics::TColor UnselectedColor = {read=FUnselectedColor, write=SetUnselectedColor, default=-2147483643
		};
	__property Visible ;
	__property int VisibleTabs = {read=FVisibleTabs, nodefault};
	__property OnClick ;
	__property TTabChangeEvent OnChange = {read=FOnChange, write=FOnChange};
	__property OnDragDrop ;
	__property OnDragOver ;
	__property OnEndDock ;
	__property OnEndDrag ;
	__property OnEnter ;
	__property OnExit ;
	__property OnMouseDown ;
	__property OnMouseMove ;
	__property OnMouseUp ;
	__property TMeasureTabEvent OnMeasureTab = {read=FOnMeasureTab, write=FOnMeasureTab};
	__property OnStartDock ;
	__property OnStartDrag ;
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TAdvTabSet(HWND ParentWindow) : Controls::TCustomControl(
		ParentWindow) { }
	#pragma option pop
	
};


class PASCALIMPLEMENTATION TTabList : public Classes::TStringList 
{
	typedef Classes::TStringList inherited;
	
private:
	TAdvTabSet* Tabs;
	
public:
	virtual void __fastcall Insert(int Index, const AnsiString S);
	virtual void __fastcall Delete(int Index);
	virtual int __fastcall Add(const AnsiString S);
	virtual void __fastcall Put(int Index, const AnsiString S);
	virtual void __fastcall Clear(void);
	virtual void __fastcall AddStrings(Classes::TStrings* Strings);
public:
	#pragma option push -w-inl
	/* TStringList.Destroy */ inline __fastcall virtual ~TTabList(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TTabList(void) : Classes::TStringList() { }
	#pragma option pop
	
};


#pragma option push -b-
enum TEdgePart { epSelectedLeft, epUnselectedLeft, epSelectedRight, epUnselectedRight };
#pragma option pop

#pragma option push -b-
enum TEdgeType { etNone, etFirstIsSel, etFirstNotSel, etLastIsSel, etLastNotSel, etNotSelToSel, etSelToNotSel, 
	etNotSelToNotSel };
#pragma option pop

class PASCALIMPLEMENTATION TTabCollectionItem : public Classes::TCollectionItem 
{
	typedef Classes::TCollectionItem inherited;
	
private:
	AnsiString FCaption;
	bool FVisible;
	bool FShowClose;
	int FImageIndex;
	int FIndexInAdvTabSet;
	void __fastcall SetCaption(const AnsiString Value);
	void __fastcall SetVisible(const bool Value);
	void __fastcall SetShowClose(const bool Value);
	void __fastcall SetImageIndex(const int Value);
	
public:
	__fastcall virtual TTabCollectionItem(Classes::TCollection* Collection);
	__fastcall virtual ~TTabCollectionItem(void);
	
__published:
	__property AnsiString Caption = {read=FCaption, write=SetCaption};
	__property bool Visible = {read=FVisible, write=SetVisible, nodefault};
	__property bool ShowClose = {read=FShowClose, write=SetShowClose, nodefault};
	__property int ImageIndex = {read=FImageIndex, write=SetImageIndex, nodefault};
};


//-- var, const, procedure ---------------------------------------------------
static const Shortint CloseButtonWidth = 0xe;
static const Shortint CloseButtonHeight = 0xd;

}	/* namespace Advtabset */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Advtabset;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// AdvTabSet
