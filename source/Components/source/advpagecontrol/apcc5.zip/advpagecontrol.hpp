// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'AdvPageControl.pas' rev: 5.00

#ifndef AdvPageControlHPP
#define AdvPageControlHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Menus.hpp>	// Pascal unit
#include <Math.hpp>	// Pascal unit
#include <ComCtrls.hpp>	// Pascal unit
#include <ImgList.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Commctrl.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Advpagecontrol
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TGradientDirection { gdVertical, gdHorizontal };
#pragma option pop

#pragma option push -b-
enum TTabStyle { tsClassic, tsDotNet };
#pragma option pop

typedef int TMarginSize;

typedef void __fastcall (__closure *TMarginChange)(TMarginSize NewValue, TMarginSize OldValue, int Index
	);

class DELPHICLASS TTabMargin;
class PASCALIMPLEMENTATION TTabMargin : public Classes::TPersistent 
{
	typedef Classes::TPersistent inherited;
	
private:
	TMarginSize FLeftMargin;
	TMarginSize FTopMargin;
	TMarginChange FOnMarginChange;
	void __fastcall SetMargin(int Index, TMarginSize Value);
	
protected:
	__property TMarginChange OnMarginChange = {read=FOnMarginChange, write=FOnMarginChange};
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	
__published:
	__property TMarginSize LeftMargin = {read=FLeftMargin, write=SetMargin, index=0, default=0};
	__property TMarginSize TopMargin = {read=FTopMargin, write=SetMargin, index=1, default=0};
public:
	#pragma option push -w-inl
	/* TPersistent.Destroy */ inline __fastcall virtual ~TTabMargin(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TTabMargin(void) : Classes::TPersistent() { }
	#pragma option pop
	
};


typedef void __fastcall (__closure *TCanCloseEvent)(System::TObject* Sender, bool &CanClose);

class DELPHICLASS TAdvTabSheet;
class DELPHICLASS TAdvPageControl;
typedef Shortint TTabOverlapSize;

class PASCALIMPLEMENTATION TAdvPageControl : public Comctrls::TCustomTabControl 
{
	typedef Comctrls::TCustomTabControl inherited;
	
private:
	Classes::TList* FPages;
	TAdvTabSheet* FActivePage;
	TAdvTabSheet* FNewDockSheet;
	TAdvTabSheet* FUndockingPage;
	TTabMargin* FTabMargin;
	Classes::TStringList* FClosedTabList;
	Classes::TNotifyEvent FOnChange;
	Imglist::TCustomImageList* FImages;
	Imglist::TCustomImageList* FDummyImages;
	Graphics::TColor FDefaultTextColor;
	Graphics::TColor FDefaultTabColor;
	Graphics::TColor FDefaultTabColorTo;
	Graphics::TColor FActiveColor;
	Graphics::TColor FActiveColorTo;
	bool FTabBorder3D;
	Graphics::TColor FTabBorderColor;
	Graphics::TColor FTabHoverColor;
	Graphics::TColor FTabHoverColorTo;
	Graphics::TColor FTabHoverBorder;
	bool FShowFocus;
	bool FHoverClosedButton;
	TTabOverlapSize FTabOverlap;
	bool FTabSheet3D;
	Graphics::TColor FTabSheetBorderColor;
	Graphics::TColor FTabBackGroundColor;
	bool FTabSplitLine;
	bool FRoundEdges;
	int FHoverTab;
	Graphics::TBitmap* FTabBackGround;
	Graphics::TBitmap* FTabBackGroundActive;
	TTabStyle FTabStyle;
	void __fastcall ChangeActivePage(TAdvTabSheet* Page);
	void __fastcall DeleteTab(TAdvTabSheet* Page, int Index);
	int __fastcall GetActivePageIndex(void);
	Controls::TControl* __fastcall GetDockClientFromMousePos(const Windows::TPoint &MousePos);
	TAdvTabSheet* __fastcall GetPage(int Index);
	int __fastcall GetPageCount(void);
	void __fastcall InsertPage(TAdvTabSheet* Page);
	void __fastcall InsertTab(TAdvTabSheet* Page);
	void __fastcall MoveTab(int CurIndex, int NewIndex);
	void __fastcall RemovePage(TAdvTabSheet* Page);
	void __fastcall SetActivePage(TAdvTabSheet* Page);
	void __fastcall SetActivePageIndex(const int Value);
	void __fastcall SetDefaultTextColor(const Graphics::TColor Value);
	void __fastcall SetDefaultTabColor(const Graphics::TColor Value);
	void __fastcall SetDefaultTabColorTo(const Graphics::TColor Value);
	void __fastcall SetActiveColor(const Graphics::TColor Value);
	void __fastcall SetActiveColorTo(const Graphics::TColor Value);
	void __fastcall SetTabBorder3D(bool Value);
	void __fastcall SetTabBorderColor(const Graphics::TColor Value);
	void __fastcall SetTabBackGround(const Graphics::TBitmap* Value);
	void __fastcall SetTabBackGroundActive(const Graphics::TBitmap* Value);
	HIDESBASE void __fastcall SetImages(Imglist::TCustomImageList* value);
	void __fastcall SetTabMargin(TTabMargin* Value);
	void __fastcall SetTabOverlap(TTabOverlapSize Value);
	void __fastcall SetTabSheet3D(bool Value);
	void __fastcall SetTabSheetBorderColor(Graphics::TColor Value);
	void __fastcall SetTabBackGroundColor(Graphics::TColor Value);
	void __fastcall SetTabSplitLine(bool Value);
	void __fastcall SetRoundEdges(bool Value);
	void __fastcall SetTabStyle(TTabStyle Value);
	void __fastcall DrawCloseButton(const Windows::TRect &Rect, bool Active);
	void __fastcall DrawHoverCloseButton(const Windows::TRect &Rect);
	void __fastcall DrawDownCloseButton(const Windows::TRect &Rect);
	bool __fastcall IsOnButton(int TabIndex, int X, int Y);
	void __fastcall TabMarginChange(TMarginSize NewValue, TMarginSize OldValue, int Index);
	void __fastcall UpdateTab(TAdvTabSheet* Page);
	void __fastcall UpdateTabHighlights(void);
	HIDESBASE MESSAGE void __fastcall CMDesignHitTest(Messages::TWMMouse &Message);
	HIDESBASE MESSAGE void __fastcall CMDialogKey(Messages::TWMKey &Message);
	HIDESBASE MESSAGE void __fastcall CMDockClient(Controls::TCMDockClient &Message);
	MESSAGE void __fastcall CMDockNotification(Controls::TCMDockNotification &Message);
	HIDESBASE MESSAGE void __fastcall CMUnDockClient(Controls::TCMUnDockClient &Message);
	HIDESBASE MESSAGE void __fastcall WMLButtonDown(Messages::TWMMouse &Message);
	HIDESBASE MESSAGE void __fastcall WMLButtonDblClk(Messages::TWMMouse &Message);
	
protected:
	virtual bool __fastcall CanShowTab(int TabIndex);
	DYNAMIC void __fastcall Change(void);
	DYNAMIC void __fastcall DoAddDockClient(Controls::TControl* Client, const Windows::TRect &ARect);
	DYNAMIC void __fastcall DockOver(Controls::TDragDockObject* Source, int X, int Y, Controls::TDragState 
		State, bool &Accept);
	DYNAMIC void __fastcall DoRemoveDockClient(Controls::TControl* Client);
	DYNAMIC void __fastcall GetChildren(Classes::TGetChildProc Proc, Classes::TComponent* Root);
	virtual int __fastcall GetImageIndex(int TabIndex);
	TAdvTabSheet* __fastcall GetPageFromDockClient(Controls::TControl* Client);
	DYNAMIC void __fastcall GetSiteInfo(Controls::TControl* Client, Windows::TRect &InfluenceRect, const 
		Windows::TPoint &MousePos, bool &CanDock);
	virtual void __fastcall Loaded(void);
	DYNAMIC void __fastcall SetChildOrder(Classes::TComponent* Child, int Order);
	virtual void __fastcall ShowControl(Controls::TControl* AControl);
	virtual void __fastcall UpdateActivePage(void);
	virtual void __fastcall WndProc(Messages::TMessage &Message);
	void __fastcall TabChange(System::TObject* Sender);
	DYNAMIC void __fastcall MouseUp(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int 
		Y);
	DYNAMIC void __fastcall MouseDown(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, 
		int Y);
	DYNAMIC void __fastcall MouseMove(Classes::TShiftState Shift, int X, int Y);
	HIDESBASE MESSAGE void __fastcall CMMouseLeave(Messages::TMessage &Message);
	void __fastcall DrawAllTabs(Graphics::TCanvas* Canvas);
	Windows::TRect __fastcall TabRectEx(int i);
	int __fastcall IndexOfTabAtEx(int X, int Y);
	
public:
	__fastcall virtual TAdvPageControl(Classes::TComponent* AOwner);
	__fastcall virtual ~TAdvPageControl(void);
	TAdvTabSheet* __fastcall FindNextPage(TAdvTabSheet* CurPage, bool GoForward, bool CheckTabVisible);
		
	void __fastcall SelectNextPage(bool GoForward);
	void __fastcall OpenAllClosedTabs(void);
	bool __fastcall OpenClosedTab(AnsiString TabName);
	__property int ActivePageIndex = {read=GetActivePageIndex, write=SetActivePageIndex, nodefault};
	__property int PageCount = {read=GetPageCount, nodefault};
	__property TAdvTabSheet* Pages[int Index] = {read=GetPage};
	
__published:
	__property TAdvTabSheet* ActivePage = {read=FActivePage, write=SetActivePage};
	__property Align ;
	__property Anchors ;
	__property BiDiMode ;
	__property Constraints ;
	__property DockSite ;
	__property DragCursor ;
	__property DragKind ;
	__property DragMode ;
	__property Enabled ;
	__property Font ;
	__property HotTrack ;
	__property Imglist::TCustomImageList* Images = {read=FImages, write=SetImages};
	__property MultiLine ;
	__property ParentBiDiMode ;
	__property ParentFont ;
	__property ParentShowHint ;
	__property PopupMenu ;
	__property RaggedRight ;
	__property ScrollOpposite ;
	__property ShowHint ;
	__property bool ShowFocus = {read=FShowFocus, write=FShowFocus, default=0};
	__property Graphics::TColor DefaultTextColor = {read=FDefaultTextColor, write=SetDefaultTextColor, 
		default=0};
	__property Graphics::TColor DefaultTabColor = {read=FDefaultTabColor, write=SetDefaultTabColor, default=-2147483633
		};
	__property Graphics::TColor DefaultTabColorTo = {read=FDefaultTabColorTo, write=SetDefaultTabColorTo
		, default=536870911};
	__property Graphics::TColor ActiveColor = {read=FActiveColor, write=SetActiveColor, default=-2147483633
		};
	__property Graphics::TColor ActiveColorTo = {read=FActiveColorTo, write=SetActiveColorTo, default=536870911
		};
	__property bool TabBorder3D = {read=FTabBorder3D, write=SetTabBorder3D, default=0};
	__property Graphics::TColor TabBorderColor = {read=FTabBorderColor, write=SetTabBorderColor, default=8421504
		};
	__property bool TabSheet3D = {read=FTabSheet3D, write=SetTabSheet3D, default=0};
	__property Graphics::TColor TabSheetBorderColor = {read=FTabSheetBorderColor, write=SetTabSheetBorderColor
		, default=8421504};
	__property Graphics::TColor TabHoverColor = {read=FTabHoverColor, write=FTabHoverColor, default=536870911
		};
	__property Graphics::TColor TabHoverColorTo = {read=FTabHoverColorTo, write=FTabHoverColorTo, default=536870911
		};
	__property Graphics::TColor TabHoverBorder = {read=FTabHoverBorder, write=FTabHoverBorder, default=536870911
		};
	__property Graphics::TColor TabBackGroundColor = {read=FTabBackGroundColor, write=SetTabBackGroundColor
		, nodefault};
	__property Graphics::TBitmap* TabBackGround = {read=FTabBackGround, write=SetTabBackGround};
	__property Graphics::TBitmap* TabBackGroundActive = {read=FTabBackGroundActive, write=SetTabBackGroundActive
		};
	__property TTabMargin* TabMargin = {read=FTabMargin, write=SetTabMargin};
	__property TTabOverlapSize TabOverlap = {read=FTabOverlap, write=SetTabOverlap, nodefault};
	__property bool TabSplitLine = {read=FTabSplitLine, write=SetTabSplitLine, default=0};
	__property bool RoundEdges = {read=FRoundEdges, write=SetRoundEdges, default=0};
	__property TTabStyle TabStyle = {read=FTabStyle, write=SetTabStyle, default=0};
	__property TabHeight ;
	__property TabOrder ;
	__property TabPosition ;
	__property TabStop ;
	__property TabWidth ;
	__property Visible ;
	__property Classes::TNotifyEvent OnChange = {read=FOnChange, write=FOnChange};
	__property OnChanging ;
	__property OnContextPopup ;
	__property OnDockDrop ;
	__property OnDockOver ;
	__property OnDragDrop ;
	__property OnDragOver ;
	__property OnDrawTab ;
	__property OnEndDock ;
	__property OnEndDrag ;
	__property OnEnter ;
	__property OnExit ;
	__property OnGetImageIndex ;
	__property OnGetSiteInfo ;
	__property OnMouseDown ;
	__property OnMouseMove ;
	__property OnMouseUp ;
	__property OnResize ;
	__property OnStartDock ;
	__property OnStartDrag ;
	__property OnUnDock ;
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TAdvPageControl(HWND ParentWindow) : Comctrls::TCustomTabControl(
		ParentWindow) { }
	#pragma option pop
	
};


class PASCALIMPLEMENTATION TAdvTabSheet : public Controls::TWinControl 
{
	typedef Controls::TWinControl inherited;
	
private:
	Graphics::TColor FTextColor;
	Graphics::TColor FTabColor;
	Graphics::TColor FTabColorTo;
	bool FShowClose;
	TGradientDirection FTabGradientDirection;
	TGradientDirection FHoverGradientDirection;
	Imglist::TImageIndex FImageIndex;
	TAdvPageControl* FAdvPageControl;
	bool FTabVisible;
	bool FTabShowing;
	bool FHighlighted;
	Classes::TNotifyEvent FOnHide;
	Classes::TNotifyEvent FOnShow;
	Classes::TNotifyEvent FOnClose;
	TCanCloseEvent FOnCanClose;
	int __fastcall GetPageIndex(void);
	int __fastcall GetTabIndex(void);
	void __fastcall SetHighlighted(bool Value);
	void __fastcall SetImageIndex(Imglist::TImageIndex Value);
	void __fastcall SetAdvPageControl(TAdvPageControl* AAdvPageControl);
	void __fastcall SetPageIndex(int Value);
	void __fastcall SetTabShowing(bool Value);
	void __fastcall SetTabVisible(bool Value);
	void __fastcall UpdateTabShowing(void);
	MESSAGE void __fastcall CMTextChanged(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMShowingChanged(Messages::TMessage &Message);
	void __fastcall CloseButtonClick(System::TObject* Sender);
	bool __fastcall CanCloseClick(System::TObject* Sender);
	void __fastcall SetShowClose(bool value);
	void __fastcall SetTabGradientDirection(TGradientDirection value);
	void __fastcall SetHoverGradientDirection(TGradientDirection value);
	void __fastcall SetTextColor(const Graphics::TColor Value);
	void __fastcall SetTabColor(const Graphics::TColor Value);
	void __fastcall SetTabColorTo(const Graphics::TColor Value);
	
protected:
	virtual void __fastcall CreateParams(Controls::TCreateParams &Params);
	DYNAMIC void __fastcall DoHide(void);
	DYNAMIC void __fastcall DoShow(void);
	virtual void __fastcall ReadState(Classes::TReader* Reader);
	
public:
	__fastcall virtual TAdvTabSheet(Classes::TComponent* AOwner);
	__fastcall virtual ~TAdvTabSheet(void);
	__property TAdvPageControl* AdvPageControl = {read=FAdvPageControl, write=SetAdvPageControl};
	__property int TabIndex = {read=GetTabIndex, nodefault};
	
__published:
	__property BorderWidth ;
	__property Caption ;
	__property DragMode ;
	__property Enabled ;
	__property Font ;
	__property Height  = {stored=false};
	__property bool Highlighted = {read=FHighlighted, write=SetHighlighted, default=0};
	__property Imglist::TImageIndex ImageIndex = {read=FImageIndex, write=SetImageIndex, default=0};
	__property Left  = {stored=false};
	__property Constraints ;
	__property TGradientDirection HoverGradientDirection = {read=FHoverGradientDirection, write=SetHoverGradientDirection
		, default=0};
	__property TGradientDirection TabGradientDirection = {read=FTabGradientDirection, write=SetTabGradientDirection
		, default=0};
	__property int PageIndex = {read=GetPageIndex, write=SetPageIndex, stored=false, nodefault};
	__property ParentFont ;
	__property ParentShowHint ;
	__property PopupMenu ;
	__property ShowHint ;
	__property bool ShowClose = {read=FShowClose, write=SetShowClose, default=0};
	__property bool TabVisible = {read=FTabVisible, write=SetTabVisible, default=1};
	__property Graphics::TColor TabColor = {read=FTabColor, write=SetTabColor, nodefault};
	__property Graphics::TColor TabColorTo = {read=FTabColorTo, write=SetTabColorTo, nodefault};
	__property Graphics::TColor TextColor = {read=FTextColor, write=SetTextColor, default=0};
	__property Top  = {stored=false};
	__property Visible  = {stored=false, default=1};
	__property Width  = {stored=false};
	__property TCanCloseEvent OnCanClose = {read=FOnCanClose, write=FOnCanClose};
	__property Classes::TNotifyEvent OnClose = {read=FOnClose, write=FOnClose};
	__property OnContextPopup ;
	__property OnDragDrop ;
	__property OnDragOver ;
	__property OnEndDrag ;
	__property OnEnter ;
	__property OnExit ;
	__property Classes::TNotifyEvent OnHide = {read=FOnHide, write=FOnHide};
	__property OnMouseDown ;
	__property OnMouseMove ;
	__property OnMouseUp ;
	__property OnResize ;
	__property Classes::TNotifyEvent OnShow = {read=FOnShow, write=FOnShow};
	__property OnStartDrag ;
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TAdvTabSheet(HWND ParentWindow) : Controls::TWinControl(
		ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
static const Shortint CloseButtonWidth = 0xe;
static const Shortint CloseButtonHeight = 0xd;

}	/* namespace Advpagecontrol */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Advpagecontrol;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// AdvPageControl
