// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'AdvTabSetReg.pas' rev: 5.00

#ifndef AdvTabSetRegHPP
#define AdvTabSetRegHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <AdvTabSet.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Advtabsetreg
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall Register(void);

}	/* namespace Advtabsetreg */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Advtabsetreg;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// AdvTabSetReg
